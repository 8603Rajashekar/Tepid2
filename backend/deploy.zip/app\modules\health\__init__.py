"""Health check module."""
